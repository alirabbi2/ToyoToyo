export default function StarRating({
  rating,
  size = "text-sm",
}: {
  rating: number;
  size?: string;
}) {
  const full = Math.round(rating);
  return (
    <span className={`${size} text-amber-400 leading-none`}>
      {"★★★★★".slice(0, full)}
      <span className="text-slate-300">{"★★★★★".slice(full)}</span>
    </span>
  );
}
