"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCart } from "./CartProvider";

export default function MobileNav() {
  const path = usePathname();
  const { count, wishlist } = useCart();

  if (path.startsWith("/admin")) return null;

  const items = [
    { href: "/", label: "Home", icon: "🏠" },
    { href: "/search", label: "Search", icon: "🔎" },
    { href: "/shop", label: "Shop", icon: "🛍" },
    { href: "/wishlist", label: "Wishlist", icon: "♡", badge: wishlist.length },
    { href: "/cart", label: "Cart", icon: "🛒", badge: count },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
      <div className="grid grid-cols-5">
        {items.map((it) => {
          const active = path === it.href;
          return (
            <Link
              key={it.label}
              href={it.href}
              className={`flex flex-col items-center py-2 text-[11px] font-semibold relative ${
                active ? "text-toyo" : "text-slate-500"
              }`}
            >
              <span className="text-xl leading-none relative">
                {it.icon}
                {!!it.badge && it.badge > 0 && (
                  <span className="absolute -top-1 -right-2 bg-toyo text-white text-[9px] rounded-full h-4 min-w-4 px-1 flex items-center justify-center">
                    {it.badge}
                  </span>
                )}
              </span>
              {it.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
