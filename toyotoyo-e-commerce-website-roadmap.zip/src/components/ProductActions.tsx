"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Product } from "@/db/schema";
import { useCart } from "./CartProvider";

export default function ProductActions({ product }: { product: Product }) {
  const { addToCart, toggleWishlist, isWishlisted } = useCart();
  const [qty, setQty] = useState(1);
  const router = useRouter();
  const eff = product.discountPrice ?? product.price;
  const wished = isWishlisted(product.id);
  const out = product.stock <= 0;

  const item = {
    productId: product.id,
    name: product.name,
    slug: product.slug,
    image: product.image,
    price: eff,
  };

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center rounded-full bg-amber-50 border border-amber-100">
          <button
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="h-10 w-10 text-xl font-bold text-slate-600"
          >
            −
          </button>
          <span className="w-10 text-center font-bold">{qty}</span>
          <button
            onClick={() => setQty((q) => q + 1)}
            className="h-10 w-10 text-xl font-bold text-slate-600"
          >
            +
          </button>
        </div>
        <span className="text-sm text-slate-500">
          {out ? "Out of stock" : `${product.stock} in stock`}
        </span>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <button
          disabled={out}
          onClick={() => addToCart(item, qty)}
          className="flex-1 rounded-full bg-toyoteal text-white font-bold py-3 hover:brightness-105 disabled:opacity-40"
        >
          🛒 Add to Cart
        </button>
        <button
          disabled={out}
          onClick={() => {
            addToCart(item, qty);
            router.push("/checkout");
          }}
          className="flex-1 rounded-full bg-toyo text-white font-bold py-3 hover:brightness-105 disabled:opacity-40"
        >
          Buy Now
        </button>
        <button
          onClick={() => toggleWishlist(product.id)}
          className={`rounded-full border-2 px-5 py-3 font-bold ${
            wished ? "border-toyo text-toyo" : "border-slate-200 text-slate-500"
          }`}
        >
          {wished ? "♥" : "♡"}
        </button>
      </div>
    </div>
  );
}
