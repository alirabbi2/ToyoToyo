"use client";

import { useEffect, useState } from "react";
import type { Product } from "@/db/schema";

export default function useProducts(ids: number[] | null) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (ids === null) return;
    if (ids.length === 0) {
      setProducts([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(`/api/products?ids=${ids.join(",")}`)
      .then((r) => r.json())
      .then((d) => setProducts(d.products ?? []))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, [ids?.join(",")]); // eslint-disable-line react-hooks/exhaustive-deps

  return { products, loading };
}
