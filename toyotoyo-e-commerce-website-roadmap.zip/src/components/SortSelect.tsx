"use client";

import { useRouter, useSearchParams } from "next/navigation";

export default function SortSelect() {
  const router = useRouter();
  const sp = useSearchParams();
  return (
    <select
      value={sp.get("sort") ?? "date"}
      onChange={(e) => {
        const params = new URLSearchParams(sp.toString());
        params.set("sort", e.target.value);
        router.push(`/shop?${params.toString()}`);
      }}
      className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold outline-none"
    >
      <option value="date">Newest</option>
      <option value="price_asc">Price: Low to High</option>
      <option value="price_desc">Price: High to Low</option>
      <option value="rating">Top Rated</option>
    </select>
  );
}
