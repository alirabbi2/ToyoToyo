"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "./CartProvider";
import type { SessionUser } from "@/lib/auth";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  { href: "/shop?ageView=1", label: "Shop by Age" },
  { href: "/shop?skillView=1", label: "Shop by Skill" },
  { href: "/learning-hub", label: "Learning Hub" },
  { href: "/about", label: "About Us" },
];

export default function Header({ user }: { user: SessionUser | null }) {
  const { count, wishlist } = useCart();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const router = useRouter();

  const search = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(`/search?q=${encodeURIComponent(q)}`);
  };

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm">
      <div className="bg-toyopurple text-white text-center text-xs md:text-sm py-1.5 px-2">
        🚚 Free delivery on orders over ৳2000 &nbsp;•&nbsp; Use code{" "}
        <span className="font-bold">TOYO10</span> for 10% off
      </div>
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex items-center gap-4 py-3">
          <Link href="/" className="flex items-center gap-1 shrink-0">
            <span className="text-3xl">🧸</span>
            <span className="brand-font text-2xl font-extrabold leading-none">
              <span className="text-toyo">Toyo</span>
              <span className="text-toyoteal">Toyo</span>
            </span>
          </Link>

          <form onSubmit={search} className="hidden md:flex flex-1 max-w-xl">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search Montessori, puzzles, STEM..."
              className="flex-1 rounded-l-full border border-slate-200 px-5 py-2.5 outline-none focus:border-toyoteal"
            />
            <button className="rounded-r-full bg-toyoteal px-6 text-white font-semibold">
              🔍
            </button>
          </form>

          <div className="flex items-center gap-3 md:gap-4 ml-auto">
            <Link href="/wishlist" className="relative hidden sm:block text-2xl" title="Wishlist">
              ♡
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-2 bg-toyo text-white text-[10px] rounded-full h-4 min-w-4 px-1 flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </Link>
            <Link href="/cart" className="relative text-2xl" title="Cart">
              🛒
              {count > 0 && (
                <span className="absolute -top-1 -right-2 bg-toyo text-white text-[10px] rounded-full h-4 min-w-4 px-1 flex items-center justify-center">
                  {count}
                </span>
              )}
            </Link>
            {user ? (
              <Link
                href={user.role === "admin" ? "/admin" : "/account"}
                className="hidden sm:flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1.5 text-sm font-semibold"
              >
                👤 {user.name.split(" ")[0]}
              </Link>
            ) : (
              <Link
                href="/login"
                className="hidden sm:flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1.5 text-sm font-semibold"
              >
                👤 Login
              </Link>
            )}
            <button
              onClick={() => setOpen((o) => !o)}
              className="md:hidden text-2xl"
              aria-label="menu"
            >
              ☰
            </button>
          </div>
        </div>

        <form onSubmit={search} className="flex md:hidden pb-3">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search toys..."
            className="flex-1 rounded-l-full border border-slate-200 px-4 py-2 outline-none"
          />
          <button className="rounded-r-full bg-toyoteal px-5 text-white">🔍</button>
        </form>

        <nav className="hidden md:flex gap-6 pb-3">
          {NAV.map((n) => (
            <Link
              key={n.label}
              href={n.href}
              className="text-sm font-semibold text-slate-600 hover:text-toyo transition"
            >
              {n.label}
            </Link>
          ))}
        </nav>
      </div>

      {open && (
        <nav className="md:hidden border-t bg-white px-4 py-3 flex flex-col gap-1">
          {NAV.map((n) => (
            <Link
              key={n.label}
              href={n.href}
              onClick={() => setOpen(false)}
              className="py-2 font-semibold text-slate-700"
            >
              {n.label}
            </Link>
          ))}
          <Link
            href={user ? (user.role === "admin" ? "/admin" : "/account") : "/login"}
            onClick={() => setOpen(false)}
            className="py-2 font-semibold text-toyo"
          >
            {user ? "My Account" : "Login / Register"}
          </Link>
        </nav>
      )}
    </header>
  );
}
