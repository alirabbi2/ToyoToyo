"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { AGE_GROUPS, CATEGORIES, PRICE_RANGES, SKILLS } from "@/lib/constants";
import { useState } from "react";

export default function ShopFilters() {
  const router = useRouter();
  const sp = useSearchParams();
  const [open, setOpen] = useState(false);

  const setParam = (updates: Record<string, string | null>) => {
    const params = new URLSearchParams(sp.toString());
    for (const [k, v] of Object.entries(updates)) {
      if (v === null) params.delete(k);
      else params.set(k, v);
    }
    params.delete("ageView");
    params.delete("skillView");
    router.push(`/shop?${params.toString()}`);
  };

  const curAge = `${sp.get("minAge")}-${sp.get("maxAge")}`;
  const curPrice = `${sp.get("minPrice")}-${sp.get("maxPrice")}`;

  const content = (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="brand-font font-extrabold text-lg">Filters</h3>
        <button
          onClick={() => router.push("/shop")}
          className="text-xs text-toyo font-semibold"
        >
          Clear all
        </button>
      </div>

      <FilterGroup title="Age">
        {AGE_GROUPS.map((a) => {
          const active = curAge === `${a.min}-${a.max}`;
          return (
            <Chip
              key={a.label}
              active={active}
              onClick={() =>
                setParam(
                  active
                    ? { minAge: null, maxAge: null }
                    : { minAge: String(a.min), maxAge: String(a.max) }
                )
              }
            >
              {a.label}
            </Chip>
          );
        })}
      </FilterGroup>

      <FilterGroup title="Price">
        {PRICE_RANGES.map((p) => {
          const active = curPrice === `${p.min}-${p.max}`;
          return (
            <Chip
              key={p.label}
              active={active}
              onClick={() =>
                setParam(
                  active
                    ? { minPrice: null, maxPrice: null }
                    : { minPrice: String(p.min), maxPrice: String(p.max) }
                )
              }
            >
              {p.label}
            </Chip>
          );
        })}
      </FilterGroup>

      <FilterGroup title="Skill">
        {SKILLS.map((s) => {
          const active = sp.get("skill") === s.label;
          return (
            <Chip
              key={s.label}
              active={active}
              onClick={() => setParam({ skill: active ? null : s.label })}
            >
              {s.emoji} {s.label}
            </Chip>
          );
        })}
      </FilterGroup>

      <FilterGroup title="Category">
        {CATEGORIES.map((c) => {
          const active = sp.get("category") === c;
          return (
            <Chip
              key={c}
              active={active}
              onClick={() => setParam({ category: active ? null : c })}
            >
              {c}
            </Chip>
          );
        })}
      </FilterGroup>
    </div>
  );

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="md:hidden w-full rounded-full bg-white shadow-sm py-2.5 font-semibold mb-4"
      >
        ⚙️ Filters
      </button>
      <aside className="hidden md:block bg-white rounded-3xl p-5 shadow-sm sticky top-40 self-start">
        {content}
      </aside>
      {open && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/40" onClick={() => setOpen(false)}>
          <div
            className="absolute left-0 top-0 bottom-0 w-80 max-w-[85%] bg-white p-5 overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {content}
            <button
              onClick={() => setOpen(false)}
              className="mt-6 w-full rounded-full bg-toyoteal text-white font-bold py-2.5"
            >
              Show Results
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="font-bold text-slate-700 mb-2 text-sm">{title}</h4>
      <div className="flex flex-wrap gap-2">{children}</div>
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
        active
          ? "bg-toyo text-white"
          : "bg-amber-50 text-slate-600 hover:bg-amber-100"
      }`}
    >
      {children}
    </button>
  );
}
