"use client";

import { useState } from "react";

export default function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <p className="text-sm text-toyoteal font-semibold">
        🎉 Thanks for subscribing!
      </p>
    );
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (email.includes("@")) setDone(true);
      }}
      className="flex"
    >
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Enter email"
        className="flex-1 rounded-l-full px-4 py-2 text-sm text-slate-900 outline-none"
      />
      <button className="rounded-r-full bg-toyo px-4 text-sm font-semibold text-white">
        Subscribe
      </button>
    </form>
  );
}
