"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Product } from "@/db/schema";
import { CATEGORIES, SKILLS } from "@/lib/constants";

export default function ProductForm({ product }: { product?: Product }) {
  const router = useRouter();
  const [f, setF] = useState({
    name: product?.name ?? "",
    slug: product?.slug ?? "",
    shortDescription: product?.shortDescription ?? "",
    description: product?.description ?? "",
    price: product?.price?.toString() ?? "",
    discountPrice: product?.discountPrice?.toString() ?? "",
    sku: product?.sku ?? "",
    stock: product?.stock?.toString() ?? "0",
    category: product?.category ?? CATEGORIES[0],
    minAge: product?.minAge?.toString() ?? "0",
    maxAge: product?.maxAge?.toString() ?? "12",
    material: product?.material ?? "",
    image: product?.image ?? "",
    gallery: (product?.gallery ?? []).join("\n"),
    whatsIncluded: (product?.whatsIncluded ?? []).join("\n"),
    howToPlay: (product?.howToPlay ?? []).join("\n"),
    learningBenefits: (product?.learningBenefits ?? []).join("\n"),
    safetyInfo: product?.safetyInfo ?? "",
    featured: product?.featured ?? false,
    bestSeller: product?.bestSeller ?? false,
    newArrival: product?.newArrival ?? false,
  });
  const [skills, setSkills] = useState<string[]>(product?.skills ?? []);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const set = (k: string, v: string | boolean) => setF((p) => ({ ...p, [k]: v }));
  const toggleSkill = (s: string) =>
    setSkills((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const payload = { ...f, skills, id: product?.id };
    const res = await fetch("/api/admin/products", {
      method: product ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const d = await res.json();
    setBusy(false);
    if (res.ok) {
      router.push("/admin/products");
      router.refresh();
    } else {
      setError(d.error || "Failed to save.");
    }
  };

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="bg-white rounded-3xl p-6 shadow-sm space-y-4">
        <h2 className="brand-font font-extrabold text-lg">Basic Info</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <Text label="Product Name" value={f.name} onChange={(v) => set("name", v)} required />
          <Text label="Slug (optional)" value={f.slug} onChange={(v) => set("slug", v)} placeholder="auto-generated" />
          <Text label="SKU" value={f.sku} onChange={(v) => set("sku", v)} />
          <Select label="Category" value={f.category} onChange={(v) => set("category", v)} options={CATEGORIES} />
          <Text label="Price (৳)" value={f.price} onChange={(v) => set("price", v)} type="number" required />
          <Text label="Discount Price (৳)" value={f.discountPrice} onChange={(v) => set("discountPrice", v)} type="number" />
          <Text label="Stock" value={f.stock} onChange={(v) => set("stock", v)} type="number" />
          <Text label="Material" value={f.material} onChange={(v) => set("material", v)} />
          <Text label="Min Age" value={f.minAge} onChange={(v) => set("minAge", v)} type="number" />
          <Text label="Max Age" value={f.maxAge} onChange={(v) => set("maxAge", v)} type="number" />
        </div>
        <Text label="Main Image URL" value={f.image} onChange={(v) => set("image", v)} />
        <Area label="Gallery Image URLs (one per line)" value={f.gallery} onChange={(v) => set("gallery", v)} />
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm space-y-4">
        <h2 className="brand-font font-extrabold text-lg">Learning Skills</h2>
        <div className="flex flex-wrap gap-2">
          {SKILLS.map((s) => (
            <button
              type="button"
              key={s.label}
              onClick={() => toggleSkill(s.label)}
              className={`rounded-full px-3 py-1.5 text-sm font-semibold ${
                skills.includes(s.label) ? "bg-toyoteal text-white" : "bg-amber-50 text-slate-600"
              }`}
            >
              {s.emoji} {s.label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm space-y-4">
        <h2 className="brand-font font-extrabold text-lg">Content</h2>
        <Area label="Short Description" value={f.shortDescription} onChange={(v) => set("shortDescription", v)} rows={2} />
        <Area label="Full Description" value={f.description} onChange={(v) => set("description", v)} rows={4} />
        <Area label="Learning Benefits (one per line)" value={f.learningBenefits} onChange={(v) => set("learningBenefits", v)} />
        <Area label="How to Play (one step per line)" value={f.howToPlay} onChange={(v) => set("howToPlay", v)} />
        <Area label="What's Included (one per line)" value={f.whatsIncluded} onChange={(v) => set("whatsIncluded", v)} />
        <Area label="Safety Information" value={f.safetyInfo} onChange={(v) => set("safetyInfo", v)} rows={2} />
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm">
        <h2 className="brand-font font-extrabold text-lg mb-3">Visibility</h2>
        <div className="flex flex-wrap gap-4">
          <Check label="Featured" checked={f.featured} onChange={(v) => set("featured", v)} />
          <Check label="Best Seller" checked={f.bestSeller} onChange={(v) => set("bestSeller", v)} />
          <Check label="New Arrival" checked={f.newArrival} onChange={(v) => set("newArrival", v)} />
        </div>
      </div>

      {error && <p className="text-toyo font-semibold">{error}</p>}
      <div className="flex gap-3">
        <button disabled={busy} className="rounded-full bg-toyo text-white font-bold px-8 py-3 disabled:opacity-50">
          {busy ? "Saving…" : product ? "Update Product" : "Publish Product"}
        </button>
        <button type="button" onClick={() => router.back()} className="rounded-full border-2 border-slate-200 font-bold px-8 py-3">
          Cancel
        </button>
      </div>
    </form>
  );
}

function Text({ label, value, onChange, type = "text", required, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean; placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="text-sm font-semibold text-slate-600">{label}{required && " *"}</span>
      <input type={type} value={value} required={required} placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 outline-none focus:border-toyoteal" />
    </label>
  );
}

function Area({ label, value, onChange, rows = 3 }: {
  label: string; value: string; onChange: (v: string) => void; rows?: number;
}) {
  return (
    <label className="block">
      <span className="text-sm font-semibold text-slate-600">{label}</span>
      <textarea value={value} rows={rows} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 outline-none focus:border-toyoteal" />
    </label>
  );
}

function Select({ label, value, onChange, options }: {
  label: string; value: string; onChange: (v: string) => void; options: string[];
}) {
  return (
    <label className="block">
      <span className="text-sm font-semibold text-slate-600">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 outline-none focus:border-toyoteal bg-white">
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}

function Check({ label, checked, onChange }: {
  label: string; checked: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex items-center gap-2 font-semibold text-slate-700 cursor-pointer">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="accent-toyo h-5 w-5" />
      {label}
    </label>
  );
}
