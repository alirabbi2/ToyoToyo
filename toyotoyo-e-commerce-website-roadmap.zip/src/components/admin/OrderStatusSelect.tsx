"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { ORDER_STATUSES } from "@/lib/constants";

export default function OrderStatusSelect({
  id,
  status,
}: {
  id: number;
  status: string;
}) {
  const router = useRouter();
  const [val, setVal] = useState(status);
  const [saving, setSaving] = useState(false);

  return (
    <select
      value={val}
      disabled={saving}
      onChange={async (e) => {
        const next = e.target.value;
        setVal(next);
        setSaving(true);
        await fetch("/api/admin/orders", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, status: next }),
        });
        setSaving(false);
        router.refresh();
      }}
      className="rounded-full border border-slate-200 px-3 py-1.5 text-sm font-semibold bg-white capitalize"
    >
      {ORDER_STATUSES.map((s) => (
        <option key={s} value={s}>
          {s.replace(/_/g, " ")}
        </option>
      ))}
    </select>
  );
}
