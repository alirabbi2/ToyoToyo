"use client";

import { useRouter } from "next/navigation";

export default function DeleteProductButton({ id }: { id: number }) {
  const router = useRouter();
  return (
    <button
      onClick={async () => {
        if (!confirm("Delete this product?")) return;
        await fetch(`/api/admin/products?id=${id}`, { method: "DELETE" });
        router.refresh();
      }}
      className="text-toyo font-bold text-sm"
    >
      Delete
    </button>
  );
}
