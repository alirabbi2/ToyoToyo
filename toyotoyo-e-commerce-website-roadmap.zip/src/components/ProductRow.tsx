import Link from "next/link";
import type { Product } from "@/db/schema";
import ProductCard from "./ProductCard";

export default function ProductRow({
  title,
  products,
  viewAll,
}: {
  title: string;
  products: Product[];
  viewAll?: string;
}) {
  return (
    <section className="mx-auto max-w-7xl px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="brand-font text-2xl md:text-3xl font-extrabold text-slate-800">
          {title}
        </h2>
        {viewAll && (
          <Link href={viewAll} className="text-toyo font-bold text-sm hover:underline">
            View All →
          </Link>
        )}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {products.slice(0, 4).map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
