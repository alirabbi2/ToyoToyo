"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function SearchBox({ initial }: { initial: string }) {
  const [q, setQ] = useState(initial);
  const router = useRouter();
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        router.push(`/search?q=${encodeURIComponent(q)}`);
      }}
      className="flex max-w-xl"
    >
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search toys, skills, categories..."
        className="flex-1 rounded-l-full border border-slate-200 px-5 py-3 outline-none focus:border-toyoteal"
      />
      <button className="rounded-r-full bg-toyoteal text-white font-bold px-6">Search</button>
    </form>
  );
}
