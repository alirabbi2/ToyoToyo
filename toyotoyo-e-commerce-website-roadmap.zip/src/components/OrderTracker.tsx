import { TRACKING_STEPS } from "@/lib/constants";

export default function OrderTracker({ status }: { status: string }) {
  if (status === "cancelled" || status === "returned") {
    return (
      <div className="bg-toyo/10 text-toyo font-bold rounded-2xl p-4 text-center capitalize">
        Order {status}
      </div>
    );
  }
  const idx = TRACKING_STEPS.findIndex((s) => s.key === status);
  const current = idx === -1 ? 0 : idx;

  return (
    <div className="flex flex-col sm:flex-row sm:items-start gap-2 sm:gap-0">
      {TRACKING_STEPS.map((step, i) => {
        const done = i < current;
        const active = i === current;
        return (
          <div key={step.key} className="flex sm:flex-col sm:items-center sm:flex-1 gap-3 sm:gap-2">
            <div className="flex sm:flex-col items-center sm:w-full">
              <div
                className={`h-8 w-8 shrink-0 rounded-full flex items-center justify-center text-sm font-bold ${
                  done ? "bg-toyoteal text-white" : active ? "bg-toyo text-white" : "bg-slate-200 text-slate-500"
                }`}
              >
                {done ? "✓" : active ? "●" : "○"}
              </div>
              {i < TRACKING_STEPS.length - 1 && (
                <div className={`hidden sm:block h-1 w-full ${done ? "bg-toyoteal" : "bg-slate-200"}`} />
              )}
            </div>
            <span className={`text-sm ${active ? "font-bold text-slate-800" : "text-slate-500"} sm:text-center`}>
              {step.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}
