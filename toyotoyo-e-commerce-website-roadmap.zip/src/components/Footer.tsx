import Link from "next/link";
import NewsletterForm from "./NewsletterForm";

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 mt-16">
      <div className="mx-auto max-w-7xl px-4 py-12 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-1 mb-3">
            <span className="text-3xl">🧸</span>
            <span className="brand-font text-2xl font-extrabold">
              <span className="text-toyo">Toyo</span>
              <span className="text-toyoteal">Toyo</span>
            </span>
          </div>
          <p className="text-sm text-slate-400">Play. Learn. Grow.</p>
          <p className="text-sm text-slate-400 mt-3">
            Educational toys designed to make learning fun for every child.
          </p>
          <div className="flex gap-3 mt-4 text-xl">
            <span>📘</span>
            <span>📷</span>
            <span>▶️</span>
          </div>
        </div>

        <div>
          <h4 className="text-white font-bold mb-3">Shop</h4>
          <ul className="space-y-2 text-sm">
            <li><Link href="/shop" className="hover:text-toyoteal">All Products</Link></li>
            <li><Link href="/shop?ageView=1" className="hover:text-toyoteal">Shop by Age</Link></li>
            <li><Link href="/shop?skillView=1" className="hover:text-toyoteal">Shop by Skill</Link></li>
            <li><Link href="/learning-hub" className="hover:text-toyoteal">Learning Hub</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-3">Support</h4>
          <ul className="space-y-2 text-sm">
            <li><Link href="/track" className="hover:text-toyoteal">Track Order</Link></li>
            <li><Link href="/faq" className="hover:text-toyoteal">FAQ</Link></li>
            <li><Link href="/contact" className="hover:text-toyoteal">Contact</Link></li>
            <li><Link href="/about" className="hover:text-toyoteal">About Us</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-3">Play & Learning Ideas</h4>
          <p className="text-sm text-slate-400 mb-3">
            Get parenting tips & new toy ideas in your inbox.
          </p>
          <NewsletterForm />
        </div>
      </div>
      <div className="border-t border-slate-800 py-5 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} ToyoToyo · Privacy Policy · Terms & Conditions
      </div>
    </footer>
  );
}
