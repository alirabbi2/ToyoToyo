"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirm: "",
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (mode === "register" && form.password !== form.confirm) {
      setError("Passwords do not match.");
      return;
    }
    setBusy(true);
    const url = mode === "login" ? "/api/auth/login" : "/api/auth/register";
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const d = await res.json();
    setBusy(false);
    if (res.ok) {
      router.push(d.role === "admin" ? "/admin" : "/account");
      router.refresh();
    } else {
      setError(d.error || "Something went wrong.");
    }
  };

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="bg-white rounded-3xl p-8 shadow-sm">
        <div className="text-center mb-6">
          <div className="text-5xl mb-2">🧸</div>
          <h1 className="brand-font text-2xl font-extrabold">
            {mode === "login" ? "Welcome Back" : "Create Account"}
          </h1>
        </div>
        <form onSubmit={submit} className="space-y-3">
          {mode === "register" && (
            <>
              <Field label="Full Name" value={form.name} onChange={(v) => set("name", v)} required />
              <Field label="Phone" value={form.phone} onChange={(v) => set("phone", v)} />
            </>
          )}
          <Field label="Email" type="email" value={form.email} onChange={(v) => set("email", v)} required />
          <Field label="Password" type="password" value={form.password} onChange={(v) => set("password", v)} required />
          {mode === "register" && (
            <Field label="Confirm Password" type="password" value={form.confirm} onChange={(v) => set("confirm", v)} required />
          )}
          {error && <p className="text-toyo text-sm">{error}</p>}
          <button
            disabled={busy}
            className="w-full rounded-full bg-toyo text-white font-bold py-3 disabled:opacity-50"
          >
            {busy ? "Please wait…" : mode === "login" ? "Login" : "Register"}
          </button>
        </form>
        <p className="text-center text-sm text-slate-500 mt-4">
          {mode === "login" ? (
            <>
              New here?{" "}
              <Link href="/register" className="text-toyo font-bold">Create an account</Link>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <Link href="/login" className="text-toyo font-bold">Login</Link>
            </>
          )}
        </p>
      </div>
    </div>
  );
}

function Field({
  label, value, onChange, type = "text", required,
}: {
  label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-sm font-semibold text-slate-600">{label}{required && " *"}</span>
      <input
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 outline-none focus:border-toyoteal"
      />
    </label>
  );
}
