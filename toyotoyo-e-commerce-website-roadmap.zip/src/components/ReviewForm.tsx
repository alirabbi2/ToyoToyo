"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function ReviewForm({
  productId,
  loggedIn,
}: {
  productId: number;
  loggedIn: boolean;
}) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  if (!loggedIn) {
    return (
      <div className="bg-amber-50 rounded-2xl p-4 text-slate-600">
        Please{" "}
        <Link href="/login" className="text-toyo font-bold underline">
          log in
        </Link>{" "}
        to write a review.
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId, rating, comment }),
    });
    setBusy(false);
    if (res.ok) {
      setComment("");
      router.refresh();
    } else {
      const d = await res.json();
      setError(d.error || "Failed to submit.");
    }
  };

  return (
    <form onSubmit={submit} className="bg-white rounded-2xl p-5 shadow-sm">
      <h4 className="font-bold mb-3">Write a Review</h4>
      <div className="flex gap-1 mb-3 text-3xl">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            type="button"
            key={n}
            onClick={() => setRating(n)}
            className={n <= rating ? "text-amber-400" : "text-slate-300"}
          >
            ★
          </button>
        ))}
      </div>
      <textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Share your experience..."
        className="w-full rounded-xl border border-slate-200 p-3 outline-none focus:border-toyoteal"
        rows={3}
      />
      {error && <p className="text-toyo text-sm mt-1">{error}</p>}
      <button
        disabled={busy}
        className="mt-3 rounded-full bg-toyoteal text-white font-bold px-6 py-2 disabled:opacity-50"
      >
        {busy ? "Submitting..." : "Submit Review"}
      </button>
    </form>
  );
}
