"use client";

import { useState } from "react";

export default function ProductGallery({
  images,
  name,
}: {
  images: string[];
  name: string;
}) {
  const [active, setActive] = useState(0);
  const list = images.length ? images : [""];

  return (
    <div>
      <div className="aspect-square rounded-3xl overflow-hidden bg-white shadow-sm flex items-center justify-center">
        {list[active] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={list[active]} alt={name} className="w-full h-full object-cover" />
        ) : (
          <span className="text-[120px]">🧸</span>
        )}
      </div>
      {list.length > 1 && (
        <div className="flex gap-2 mt-3">
          {list.map((img, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`h-16 w-16 rounded-xl overflow-hidden border-2 ${
                active === i ? "border-toyo" : "border-transparent"
              }`}
            >
              {img ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={img} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-2xl">🧸</span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
