"use client";

import Link from "next/link";
import type { Product } from "@/db/schema";
import { formatTk } from "@/lib/constants";
import { useCart } from "./CartProvider";
import StarRating from "./StarRating";

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart, toggleWishlist, isWishlisted } = useCart();
  const eff = product.discountPrice ?? product.price;
  const hasDiscount = product.discountPrice && product.discountPrice < product.price;
  const wished = isWishlisted(product.id);

  return (
    <div className="group bg-white rounded-3xl p-3 shadow-sm hover:shadow-xl transition border border-transparent hover:border-amber-100 flex flex-col">
      <div className="relative">
        <Link href={`/product/${product.slug}`}>
          <div className="aspect-square rounded-2xl overflow-hidden bg-amber-50 flex items-center justify-center">
            {product.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
            ) : (
              <span className="text-6xl">🧸</span>
            )}
          </div>
        </Link>
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.newArrival && (
            <span className="bg-toyoteal text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
              NEW
            </span>
          )}
          {product.bestSeller && (
            <span className="bg-toyoyellow text-slate-900 text-[10px] font-bold px-2 py-0.5 rounded-full">
              BESTSELLER
            </span>
          )}
          {hasDiscount && (
            <span className="bg-toyo text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
              -{Math.round((1 - eff / product.price) * 100)}%
            </span>
          )}
        </div>
        <button
          onClick={() => toggleWishlist(product.id)}
          className={`absolute top-2 right-2 h-8 w-8 rounded-full bg-white shadow flex items-center justify-center text-lg ${
            wished ? "text-toyo" : "text-slate-400"
          }`}
          aria-label="wishlist"
        >
          {wished ? "♥" : "♡"}
        </button>
      </div>

      <div className="pt-3 px-1 flex flex-col flex-1">
        <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1">
          <span className="bg-amber-100 rounded-full px-2 py-0.5 font-semibold">
            {product.minAge}–{product.maxAge} yrs
          </span>
          {product.skills[0] && (
            <span className="truncate">{product.skills[0]}</span>
          )}
        </div>
        <Link
          href={`/product/${product.slug}`}
          className="font-bold text-slate-800 leading-snug line-clamp-2 hover:text-toyo"
        >
          {product.name}
        </Link>
        <div className="flex items-center gap-1 mt-1">
          <StarRating rating={product.rating} />
          <span className="text-[11px] text-slate-400">({product.reviewCount})</span>
        </div>
        <div className="mt-auto pt-2 flex items-end justify-between gap-2">
          <div>
            <span className="text-lg font-extrabold text-toyo">{formatTk(eff)}</span>
            {hasDiscount && (
              <span className="ml-1 text-xs text-slate-400 line-through">
                {formatTk(product.price)}
              </span>
            )}
          </div>
        </div>
        <button
          onClick={() =>
            addToCart({
              productId: product.id,
              name: product.name,
              slug: product.slug,
              image: product.image,
              price: eff,
            })
          }
          disabled={product.stock <= 0}
          className="mt-2 w-full rounded-full bg-toyoteal text-white font-bold py-2 text-sm hover:brightness-105 disabled:opacity-40"
        >
          {product.stock <= 0 ? "Out of Stock" : "Add to Cart"}
        </button>
      </div>
    </div>
  );
}
