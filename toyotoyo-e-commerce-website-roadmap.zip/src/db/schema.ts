import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  jsonb,
  real,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  phone: varchar("phone", { length: 32 }),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 32 }).notNull().default("customer"), // customer | admin
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  shortDescription: text("short_description").notNull().default(""),
  description: text("description").notNull().default(""),
  price: integer("price").notNull(), // in BDT (whole taka)
  discountPrice: integer("discount_price"), // nullable
  sku: varchar("sku", { length: 64 }).notNull().default(""),
  stock: integer("stock").notNull().default(0),
  category: varchar("category", { length: 64 }).notNull().default("Puzzles"),
  minAge: integer("min_age").notNull().default(0),
  maxAge: integer("max_age").notNull().default(12),
  skills: jsonb("skills").$type<string[]>().notNull().default([]),
  material: varchar("material", { length: 128 }).notNull().default(""),
  image: text("image").notNull().default(""),
  gallery: jsonb("gallery").$type<string[]>().notNull().default([]),
  whatsIncluded: jsonb("whats_included").$type<string[]>().notNull().default([]),
  howToPlay: jsonb("how_to_play").$type<string[]>().notNull().default([]),
  learningBenefits: jsonb("learning_benefits").$type<string[]>().notNull().default([]),
  safetyInfo: text("safety_info").notNull().default(""),
  rating: real("rating").notNull().default(0),
  reviewCount: integer("review_count").notNull().default(0),
  featured: boolean("featured").notNull().default(false),
  bestSeller: boolean("best_seller").notNull().default(false),
  newArrival: boolean("new_arrival").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderCode: varchar("order_code", { length: 32 }).notNull().unique(),
  userId: integer("user_id"),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 32 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull().default(""),
  division: varchar("division", { length: 128 }).notNull().default(""),
  district: varchar("district", { length: 128 }).notNull().default(""),
  area: varchar("area", { length: 128 }).notNull().default(""),
  address: text("address").notNull().default(""),
  postalCode: varchar("postal_code", { length: 16 }).notNull().default(""),
  deliveryMethod: varchar("delivery_method", { length: 32 }).notNull().default("standard"),
  paymentMethod: varchar("payment_method", { length: 32 }).notNull().default("cod"),
  paymentStatus: varchar("payment_status", { length: 32 }).notNull().default("unpaid"),
  status: varchar("status", { length: 32 }).notNull().default("pending"),
  items: jsonb("items").$type<OrderItem[]>().notNull().default([]),
  subtotal: integer("subtotal").notNull().default(0),
  deliveryCharge: integer("delivery_charge").notNull().default(0),
  discount: integer("discount").notNull().default(0),
  total: integer("total").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type OrderItem = {
  productId: number;
  name: string;
  slug: string;
  image: string;
  price: number;
  quantity: number;
};

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  userId: integer("user_id"),
  authorName: varchar("author_name", { length: 255 }).notNull(),
  rating: integer("rating").notNull().default(5),
  comment: text("comment").notNull().default(""),
  approved: boolean("approved").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Review = typeof reviews.$inferSelect;
