import { db } from "@/db";
import { users, orders } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { formatTk } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function AdminCustomers() {
  const rows = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      phone: users.phone,
      createdAt: users.createdAt,
      orderCount: sql<number>`COUNT(${orders.id})`,
      spent: sql<number>`COALESCE(SUM(${orders.total}), 0)`,
    })
    .from(users)
    .leftJoin(orders, eq(orders.userId, users.id))
    .where(eq(users.role, "customer"))
    .groupBy(users.id)
    .orderBy(desc(users.createdAt));

  return (
    <div>
      <h1 className="brand-font text-3xl font-extrabold mb-6">Customers ({rows.length})</h1>
      <div className="bg-white rounded-3xl shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-amber-50 text-slate-500">
            <tr>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Contact</th>
              <th className="text-left p-3">Orders</th>
              <th className="text-left p-3">Total Spent</th>
              <th className="text-left p-3">Joined</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={5} className="p-8 text-center text-slate-400">No customers yet.</td></tr>
            )}
            {rows.map((c) => (
              <tr key={c.id} className="border-t">
                <td className="p-3 font-semibold">{c.name}</td>
                <td className="p-3 text-slate-500">{c.email}<br />{c.phone}</td>
                <td className="p-3 font-bold">{Number(c.orderCount)}</td>
                <td className="p-3 font-bold text-toyo">{formatTk(Number(c.spent))}</td>
                <td className="p-3 text-slate-500">{new Date(c.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
