import ProductForm from "@/components/admin/ProductForm";

export const dynamic = "force-dynamic";

export default function NewProductPage() {
  return (
    <div>
      <h1 className="brand-font text-3xl font-extrabold mb-6">Add Product</h1>
      <ProductForm />
    </div>
  );
}
