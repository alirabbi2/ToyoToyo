import { notFound } from "next/navigation";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import ProductForm from "@/components/admin/ProductForm";

export const dynamic = "force-dynamic";

export default async function EditProductPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const rows = await db.select().from(products).where(eq(products.id, Number(id)));
  const product = rows[0];
  if (!product) notFound();

  return (
    <div>
      <h1 className="brand-font text-3xl font-extrabold mb-6">Edit Product</h1>
      <ProductForm product={product} />
    </div>
  );
}
