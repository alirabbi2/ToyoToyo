import Link from "next/link";
import { db } from "@/db";
import { products } from "@/db/schema";
import { desc } from "drizzle-orm";
import { formatTk } from "@/lib/constants";
import DeleteProductButton from "@/components/admin/DeleteProductButton";

export const dynamic = "force-dynamic";

export default async function AdminProducts() {
  const list = await db.select().from(products).orderBy(desc(products.createdAt));

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="brand-font text-3xl font-extrabold">Products ({list.length})</h1>
        <Link href="/admin/products/new" className="rounded-full bg-toyo text-white font-bold px-5 py-2.5">
          + Add Product
        </Link>
      </div>

      <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-amber-50 text-slate-500">
              <tr>
                <th className="text-left p-3">Product</th>
                <th className="text-left p-3">Category</th>
                <th className="text-left p-3">Price</th>
                <th className="text-left p-3">Stock</th>
                <th className="text-left p-3">Status</th>
                <th className="text-right p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.length === 0 && (
                <tr><td colSpan={6} className="p-8 text-center text-slate-400">No products yet.</td></tr>
              )}
              {list.map((p) => (
                <tr key={p.id} className="border-t">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="h-10 w-10 rounded-lg bg-amber-50 overflow-hidden flex items-center justify-center shrink-0">
                        {p.image ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={p.image} alt="" className="w-full h-full object-cover" />
                        ) : "🧸"}
                      </div>
                      <span className="font-semibold line-clamp-1">{p.name}</span>
                    </div>
                  </td>
                  <td className="p-3 text-slate-500">{p.category}</td>
                  <td className="p-3 font-semibold">{formatTk(p.discountPrice ?? p.price)}</td>
                  <td className="p-3">
                    <span className={p.stock <= 5 ? "text-toyo font-bold" : ""}>{p.stock}</span>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1 flex-wrap">
                      {p.featured && <Badge>Featured</Badge>}
                      {p.bestSeller && <Badge>Best</Badge>}
                      {p.newArrival && <Badge>New</Badge>}
                    </div>
                  </td>
                  <td className="p-3 text-right space-x-3">
                    <Link href={`/admin/products/${p.id}`} className="text-toyoteal font-bold">Edit</Link>
                    <DeleteProductButton id={p.id} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Badge({ children }: { children: React.ReactNode }) {
  return <span className="bg-amber-100 rounded-full px-2 py-0.5 text-xs font-bold">{children}</span>;
}
