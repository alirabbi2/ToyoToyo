import { getAllOrders } from "@/lib/orders";
import { formatTk } from "@/lib/constants";
import OrderStatusSelect from "@/components/admin/OrderStatusSelect";

export const dynamic = "force-dynamic";

export default async function AdminOrders() {
  const orders = await getAllOrders();

  return (
    <div>
      <h1 className="brand-font text-3xl font-extrabold mb-6">Orders ({orders.length})</h1>
      {orders.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 text-center text-slate-400">No orders yet.</div>
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="bg-white rounded-3xl p-5 shadow-sm">
              <div className="flex justify-between flex-wrap gap-3 items-start">
                <div>
                  <div className="font-extrabold text-lg">{o.orderCode}</div>
                  <div className="text-sm text-slate-500">
                    {new Date(o.createdAt).toLocaleString()}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-extrabold text-toyo text-lg">{formatTk(o.total)}</span>
                  <OrderStatusSelect id={o.id} status={o.status} />
                </div>
              </div>

              <div className="grid sm:grid-cols-3 gap-4 mt-4 text-sm">
                <div>
                  <div className="font-bold text-slate-700 mb-1">Customer</div>
                  <p className="text-slate-500">
                    {o.customerName}<br />{o.customerPhone}<br />{o.customerEmail}
                  </p>
                </div>
                <div>
                  <div className="font-bold text-slate-700 mb-1">Ship To</div>
                  <p className="text-slate-500">
                    {o.address}, {o.area}<br />{o.district}, {o.division} {o.postalCode}
                  </p>
                </div>
                <div>
                  <div className="font-bold text-slate-700 mb-1">Payment</div>
                  <p className="text-slate-500 capitalize">
                    {o.paymentMethod} · {o.paymentStatus}<br />
                    {o.deliveryMethod} delivery
                  </p>
                </div>
              </div>

              <details className="mt-3">
                <summary className="cursor-pointer text-toyoteal font-bold text-sm">
                  {o.items.length} item(s)
                </summary>
                <div className="mt-2 space-y-1 text-sm">
                  {o.items.map((it) => (
                    <div key={it.productId} className="flex justify-between">
                      <span>{it.name} × {it.quantity}</span>
                      <span className="font-semibold">{formatTk(it.price * it.quantity)}</span>
                    </div>
                  ))}
                </div>
              </details>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
