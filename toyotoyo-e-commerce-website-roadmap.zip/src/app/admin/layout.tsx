import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import LogoutButton from "@/components/LogoutButton";

export const dynamic = "force-dynamic";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") redirect("/");

  const nav = [
    { href: "/admin", label: "Dashboard", icon: "📊" },
    { href: "/admin/products", label: "Products", icon: "🧸" },
    { href: "/admin/orders", label: "Orders", icon: "📦" },
    { href: "/admin/customers", label: "Customers", icon: "👥" },
  ];

  return (
    <div className="min-h-screen bg-slate-100">
      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <Link href="/admin" className="flex items-center gap-2">
            <span className="text-2xl">🧸</span>
            <span className="brand-font font-extrabold text-xl">
              ToyoToyo <span className="text-toyo">Admin</span>
            </span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/" className="text-sm font-semibold text-slate-500">
              View Store ↗
            </Link>
            <LogoutButton className="rounded-full bg-white px-4 py-1.5 text-sm font-bold shadow-sm" />
          </div>
        </div>
        <div className="grid md:grid-cols-[220px_1fr] gap-6">
          <aside className="bg-white rounded-3xl p-3 shadow-sm h-fit md:sticky md:top-6">
            <nav className="flex md:flex-col gap-1 overflow-x-auto no-scrollbar">
              {nav.map((n) => (
                <Link
                  key={n.href}
                  href={n.href}
                  className="flex items-center gap-2 rounded-2xl px-4 py-2.5 font-semibold text-slate-600 hover:bg-amber-50 whitespace-nowrap"
                >
                  <span>{n.icon}</span> {n.label}
                </Link>
              ))}
            </nav>
          </aside>
          <div>{children}</div>
        </div>
      </div>
    </div>
  );
}
