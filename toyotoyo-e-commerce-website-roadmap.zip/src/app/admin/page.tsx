import Link from "next/link";
import { db } from "@/db";
import { orders, products, users } from "@/db/schema";
import { sql, gte, lte, desc, eq } from "drizzle-orm";
import { formatTk } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const [
    salesRow,
    orderCount,
    todayCount,
    pendingCount,
    customerCount,
    productCount,
    lowStock,
    recent,
  ] = await Promise.all([
    db
      .select({ total: sql<number>`COALESCE(SUM(${orders.total}), 0)` })
      .from(orders)
      .where(eq(orders.status, "delivered")),
    db.select({ c: sql<number>`COUNT(*)` }).from(orders),
    db.select({ c: sql<number>`COUNT(*)` }).from(orders).where(gte(orders.createdAt, startOfDay)),
    db.select({ c: sql<number>`COUNT(*)` }).from(orders).where(eq(orders.status, "pending")),
    db.select({ c: sql<number>`COUNT(*)` }).from(users).where(eq(users.role, "customer")),
    db.select({ c: sql<number>`COUNT(*)` }).from(products),
    db.select().from(products).where(lte(products.stock, 5)).orderBy(products.stock).limit(5),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(6),
  ]);

  const cards = [
    { label: "Total Sales (delivered)", value: formatTk(Number(salesRow[0].total)), emoji: "💰" },
    { label: "Total Orders", value: String(orderCount[0].c), emoji: "📦" },
    { label: "Today's Orders", value: String(todayCount[0].c), emoji: "📅" },
    { label: "Pending Orders", value: String(pendingCount[0].c), emoji: "⏳" },
    { label: "Total Customers", value: String(customerCount[0].c), emoji: "👥" },
    { label: "Total Products", value: String(productCount[0].c), emoji: "🧸" },
  ];

  return (
    <div>
      <h1 className="brand-font text-3xl font-extrabold mb-6">Dashboard</h1>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {cards.map((c) => (
          <div key={c.label} className="bg-white rounded-3xl p-5 shadow-sm">
            <div className="text-3xl mb-1">{c.emoji}</div>
            <div className="text-2xl font-extrabold">{c.value}</div>
            <div className="text-sm text-slate-500">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-3xl p-5 shadow-sm">
          <div className="flex justify-between mb-4">
            <h2 className="brand-font font-extrabold text-lg">Recent Orders</h2>
            <Link href="/admin/orders" className="text-toyo font-bold text-sm">All →</Link>
          </div>
          {recent.length === 0 ? (
            <p className="text-slate-500 text-sm">No orders yet.</p>
          ) : (
            <div className="space-y-2">
              {recent.map((o) => (
                <Link
                  key={o.id}
                  href="/admin/orders"
                  className="flex justify-between items-center text-sm border-b last:border-0 py-2"
                >
                  <div>
                    <div className="font-bold">{o.orderCode}</div>
                    <div className="text-slate-400">{o.customerName}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-toyo">{formatTk(o.total)}</div>
                    <div className="text-xs capitalize text-slate-400">{o.status.replace(/_/g, " ")}</div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm">
          <div className="flex justify-between mb-4">
            <h2 className="brand-font font-extrabold text-lg">Low Stock ⚠️</h2>
            <Link href="/admin/products" className="text-toyo font-bold text-sm">Manage →</Link>
          </div>
          {lowStock.length === 0 ? (
            <p className="text-slate-500 text-sm">All products well stocked.</p>
          ) : (
            <div className="space-y-2">
              {lowStock.map((p) => (
                <div key={p.id} className="flex justify-between text-sm border-b last:border-0 py-2">
                  <span className="truncate pr-2">{p.name}</span>
                  <span className={`font-bold ${p.stock === 0 ? "text-toyo" : "text-amber-500"}`}>
                    {p.stock} left
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
