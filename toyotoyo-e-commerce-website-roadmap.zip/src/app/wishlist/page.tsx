"use client";

import Link from "next/link";
import useSWRLike from "@/components/useProducts";
import { useCart } from "@/components/CartProvider";
import ProductCard from "@/components/ProductCard";

export default function WishlistPage() {
  const { wishlist, ready } = useCart();
  const { products, loading } = useSWRLike(ready ? wishlist : null);

  if (!ready || loading)
    return <div className="p-12 text-center text-slate-400">Loading…</div>;

  if (wishlist.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20 text-center">
        <div className="text-7xl mb-4">💝</div>
        <h1 className="brand-font text-2xl font-extrabold mb-2">Your wishlist is empty</h1>
        <p className="text-slate-500 mb-6">Tap the ♡ on any toy to save it here.</p>
        <Link href="/shop" className="rounded-full bg-toyoteal text-white font-bold px-8 py-3">
          Browse Toys
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="brand-font text-3xl font-extrabold mb-6">My Wishlist</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}
