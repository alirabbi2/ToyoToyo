import NewsletterForm from "@/components/NewsletterForm";

export const metadata = { title: "Contact · ToyoToyo" };

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="brand-font text-4xl font-extrabold mb-6">Contact Us</h1>
      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <Card e="📞" t="Call Us" d="+880 1700-000000" />
        <Card e="✉️" t="Email" d="hello@toyotoyo.com" />
        <Card e="📍" t="Address" d="Dhaka, Bangladesh" />
      </div>
      <div className="bg-white rounded-3xl p-6 shadow-sm">
        <h2 className="brand-font font-extrabold text-xl mb-2">Stay in the loop</h2>
        <p className="text-slate-500 mb-4">Get play & learning ideas in your inbox.</p>
        <div className="max-w-sm">
          <NewsletterForm />
        </div>
      </div>
    </div>
  );
}

function Card({ e, t, d }: { e: string; t: string; d: string }) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm text-center">
      <div className="text-3xl mb-1">{e}</div>
      <div className="font-bold">{t}</div>
      <div className="text-slate-500 text-sm">{d}</div>
    </div>
  );
}
