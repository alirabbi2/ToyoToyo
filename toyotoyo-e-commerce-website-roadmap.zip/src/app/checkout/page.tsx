"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { formatTk } from "@/lib/constants";

export default function CheckoutPage() {
  const { items, subtotal, clearCart, ready } = useCart();
  const router = useRouter();
  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    division: "",
    district: "",
    area: "",
    address: "",
    postalCode: "",
    deliveryMethod: "standard",
    paymentMethod: "cod",
    coupon: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  if (!ready) return <div className="p-12 text-center text-slate-400">Loading…</div>;

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20 text-center">
        <div className="text-7xl mb-4">🛒</div>
        <p className="text-slate-500 mb-6">Your cart is empty.</p>
        <Link href="/shop" className="rounded-full bg-toyoteal text-white font-bold px-8 py-3">
          Shop Now
        </Link>
      </div>
    );
  }

  const delivery = form.deliveryMethod === "express" ? 150 : subtotal >= 2000 ? 0 : 60;
  const discount =
    form.coupon.toUpperCase() === "TOYO10" && subtotal >= 1000
      ? Math.min(Math.round(subtotal * 0.1), 500)
      : 0;
  const total = subtotal + delivery - discount;

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
      }),
    });
    const d = await res.json();
    setBusy(false);
    if (res.ok) {
      clearCart();
      router.push(`/order/${d.orderCode}`);
    } else {
      setError(d.error || "Order failed. Please try again.");
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="brand-font text-3xl font-extrabold mb-6">Checkout</h1>
      <form onSubmit={submit} className="grid md:grid-cols-[1fr_320px] gap-6">
        <div className="space-y-6">
          <Card title="1 · Customer Information">
            <div className="grid sm:grid-cols-2 gap-3">
              <Input label="Full Name" value={form.customerName} onChange={(v) => set("customerName", v)} required />
              <Input label="Phone" value={form.customerPhone} onChange={(v) => set("customerPhone", v)} required />
              <Input label="Email" value={form.customerEmail} onChange={(v) => set("customerEmail", v)} type="email" full />
            </div>
          </Card>

          <Card title="2 · Shipping Address">
            <div className="grid sm:grid-cols-2 gap-3">
              <Input label="Division" value={form.division} onChange={(v) => set("division", v)} />
              <Input label="District" value={form.district} onChange={(v) => set("district", v)} />
              <Input label="Area" value={form.area} onChange={(v) => set("area", v)} />
              <Input label="Postal Code" value={form.postalCode} onChange={(v) => set("postalCode", v)} />
              <Input label="Full Address" value={form.address} onChange={(v) => set("address", v)} required full />
            </div>
          </Card>

          <Card title="3 · Delivery Method">
            <div className="space-y-2">
              <RadioRow name="delivery" checked={form.deliveryMethod === "standard"} onChange={() => set("deliveryMethod", "standard")} label="Standard Delivery (2–4 days)" note={subtotal >= 2000 ? "FREE" : "৳60"} />
              <RadioRow name="delivery" checked={form.deliveryMethod === "express"} onChange={() => set("deliveryMethod", "express")} label="Express Delivery (1 day)" note="৳150" />
            </div>
          </Card>

          <Card title="4 · Payment Method">
            <div className="space-y-2">
              <RadioRow name="pay" checked={form.paymentMethod === "cod"} onChange={() => set("paymentMethod", "cod")} label="💵 Cash on Delivery" />
              <RadioRow name="pay" checked={form.paymentMethod === "mobile"} onChange={() => set("paymentMethod", "mobile")} label="📱 Mobile Payment (bKash / Nagad)" />
              <RadioRow name="pay" checked={form.paymentMethod === "online"} onChange={() => set("paymentMethod", "online")} label="💳 Online Payment (Card)" />
            </div>
          </Card>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm h-fit sticky top-40">
          <h2 className="brand-font font-extrabold text-xl mb-4">Your Order</h2>
          <div className="space-y-2 max-h-48 overflow-y-auto mb-3">
            {items.map((it) => (
              <div key={it.productId} className="flex justify-between text-sm">
                <span className="truncate pr-2">{it.name} × {it.quantity}</span>
                <span className="font-semibold shrink-0">{formatTk(it.price * it.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-2 mb-3">
            <input
              value={form.coupon}
              onChange={(e) => set("coupon", e.target.value)}
              placeholder="Coupon (TOYO10)"
              className="flex-1 rounded-full border border-slate-200 px-3 py-2 text-sm"
            />
          </div>
          <Row label="Subtotal" value={formatTk(subtotal)} />
          <Row label="Delivery" value={delivery === 0 ? "FREE" : formatTk(delivery)} />
          {discount > 0 && <Row label="Discount" value={"-" + formatTk(discount)} />}
          <div className="border-t my-2" />
          <Row label="Total" value={formatTk(total)} bold />
          {error && <p className="text-toyo text-sm mt-2">{error}</p>}
          <button
            disabled={busy}
            className="mt-4 w-full rounded-full bg-toyo text-white font-bold py-3 disabled:opacity-50"
          >
            {busy ? "Placing Order…" : "Place Order"}
          </button>
        </div>
      </form>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm">
      <h3 className="brand-font font-extrabold text-lg mb-4">{title}</h3>
      {children}
    </div>
  );
}

function Input({
  label, value, onChange, required, type = "text", full,
}: {
  label: string; value: string; onChange: (v: string) => void; required?: boolean; type?: string; full?: boolean;
}) {
  return (
    <label className={`block ${full ? "sm:col-span-2" : ""}`}>
      <span className="text-sm font-semibold text-slate-600">{label}{required && " *"}</span>
      <input
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 outline-none focus:border-toyoteal"
      />
    </label>
  );
}

function RadioRow({
  name, checked, onChange, label, note,
}: {
  name: string; checked: boolean; onChange: () => void; label: string; note?: string;
}) {
  return (
    <label className={`flex items-center gap-3 rounded-xl border-2 p-3 cursor-pointer ${checked ? "border-toyoteal bg-toyoteal/5" : "border-slate-100"}`}>
      <input type="radio" name={name} checked={checked} onChange={onChange} className="accent-toyoteal" />
      <span className="flex-1 font-semibold text-slate-700">{label}</span>
      {note && <span className="font-bold text-slate-600">{note}</span>}
    </label>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex justify-between py-0.5 ${bold ? "text-lg font-extrabold" : "text-slate-600"}`}>
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
