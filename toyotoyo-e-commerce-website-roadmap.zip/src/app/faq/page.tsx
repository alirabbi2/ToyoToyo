export const metadata = { title: "FAQ · ToyoToyo" };

const FAQS = [
  { q: "How do I choose the right toy for my child's age?", a: "Use our Shop by Age filter. Each product also lists a recommended age range." },
  { q: "What does 'Shop by Skill' mean?", a: "We tag every toy with the skills it develops — like STEM, creativity, or fine motor skills — so you can shop by learning goal." },
  { q: "What payment methods do you accept?", a: "Cash on Delivery, Mobile Payment (bKash/Nagad), and Online Card payment." },
  { q: "How long does delivery take?", a: "Standard delivery takes 2–4 days. Express delivery arrives within 1 day." },
  { q: "Do you offer free delivery?", a: "Yes! Orders over ৳2000 qualify for free standard delivery." },
  { q: "Can I return a product?", a: "Yes, unopened products can be returned within 7 days of delivery." },
];

export default function FAQPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="brand-font text-4xl font-extrabold mb-6">FAQ</h1>
      <div className="space-y-3">
        {FAQS.map((f) => (
          <details key={f.q} className="bg-white rounded-2xl p-5 shadow-sm group">
            <summary className="font-bold text-slate-800 cursor-pointer list-none flex justify-between">
              {f.q}
              <span className="text-toyo group-open:rotate-45 transition">＋</span>
            </summary>
            <p className="text-slate-600 mt-3">{f.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
