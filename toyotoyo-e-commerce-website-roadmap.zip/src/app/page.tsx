import Link from "next/link";
import { getProducts } from "@/lib/products";
import ProductRow from "@/components/ProductRow";
import { AGE_GROUPS, SKILLS } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [featured, bestSellers, newArrivals] = await Promise.all([
    getProducts({ featured: true }),
    getProducts({ bestSeller: true }),
    getProducts({ newArrival: true, sort: "date" }),
  ]);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-toyopurple via-[#8a6bff] to-toyoteal text-white">
        <div className="mx-auto max-w-7xl px-4 py-14 md:py-20 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <span className="inline-block bg-white/20 rounded-full px-4 py-1 text-sm font-semibold mb-4">
              🧸 Play + Learn = ToyoToyo
            </span>
            <h1 className="brand-font text-4xl md:text-6xl font-extrabold leading-tight">
              Play Today.
              <br />
              Learn for Tomorrow.
            </h1>
            <p className="mt-4 text-lg text-white/90 max-w-md">
              Educational toys designed to make learning fun. Handpicked for every
              age, skill and interest.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                href="/shop"
                className="rounded-full bg-white text-toyopurple font-bold px-7 py-3 shadow-lg hover:scale-105 transition"
              >
                Shop Now
              </Link>
              <Link
                href="/shop?ageView=1"
                className="rounded-full bg-toyoyellow text-slate-900 font-bold px-7 py-3 shadow-lg hover:scale-105 transition"
              >
                Explore by Age
              </Link>
            </div>
          </div>
          <div className="hidden md:flex justify-center">
            <div className="text-[180px] leading-none rotate-6 drop-shadow-2xl">🎁</div>
          </div>
        </div>
        <div className="absolute -bottom-1 left-0 right-0 h-8 bg-amber-50 rounded-t-[50%]" />
      </section>

      {/* Shop by Age */}
      <section className="mx-auto max-w-7xl px-4 py-10">
        <SectionHead title="Shop by Age" subtitle="Find the perfect toy for your child" />
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {AGE_GROUPS.map((a) => (
            <Link
              key={a.label}
              href={`/shop?minAge=${a.min}&maxAge=${a.max}`}
              className="group bg-white rounded-3xl p-5 text-center shadow-sm hover:shadow-lg hover:-translate-y-1 transition"
            >
              <div className="text-5xl mb-2 group-hover:scale-110 transition">{a.emoji}</div>
              <div className="font-bold text-slate-800">{a.label}</div>
            </Link>
          ))}
        </div>
      </section>

      {/* Shop by Skill */}
      <section className="mx-auto max-w-7xl px-4 py-6">
        <SectionHead title="Shop by Skill" subtitle="What will your child learn?" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {SKILLS.map((s) => (
            <Link
              key={s.label}
              href={`/shop?skill=${encodeURIComponent(s.label)}`}
              className="flex items-center gap-3 bg-white rounded-2xl p-4 shadow-sm hover:shadow-lg transition"
            >
              <span className="text-3xl">{s.emoji}</span>
              <span className="font-semibold text-slate-700">{s.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {featured.length > 0 && (
        <ProductRow title="Featured Products" products={featured} viewAll="/shop?featured=1" />
      )}

      {/* Why ToyoToyo */}
      <section className="bg-white py-12 mt-10">
        <div className="mx-auto max-w-7xl px-4">
          <SectionHead title="Why ToyoToyo?" subtitle="More than just toys" center />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { e: "🧠", t: "Learn", d: "New skills through play." },
              { e: "🎨", t: "Create", d: "Boost your child's creativity." },
              { e: "🧩", t: "Think", d: "Develop problem-solving." },
              { e: "❤️", t: "Grow", d: "Support overall development." },
            ].map((c) => (
              <div key={c.t} className="text-center">
                <div className="text-5xl mb-3">{c.e}</div>
                <h3 className="brand-font font-bold text-xl text-slate-800">{c.t}</h3>
                <p className="text-sm text-slate-500 mt-1">{c.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {bestSellers.length > 0 && (
        <ProductRow title="Best Sellers" products={bestSellers} viewAll="/shop?bestSeller=1" />
      )}
      {newArrivals.length > 0 && (
        <ProductRow title="New Arrivals" products={newArrivals} viewAll="/shop?newArrival=1" />
      )}

      {/* Parent's Choice */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="bg-toyoteal/10 rounded-3xl p-8 md:p-10">
          <SectionHead title="Parent's Choice" subtitle="Toys you can trust" center />
          <div className="flex flex-wrap justify-center gap-4">
            {[
              "Age Appropriate",
              "Learning Focused",
              "Child Friendly",
              "Quality Checked",
              "Safe Materials",
            ].map((t) => (
              <span
                key={t}
                className="bg-white rounded-full px-5 py-2 font-semibold text-slate-700 shadow-sm"
              >
                ✓ {t}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="mx-auto max-w-7xl px-4 pb-12">
        <SectionHead title="Loved by Parents" subtitle="What families say" center />
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              q: "My daughter loves the activity kit and now spends less time on the phone.",
              n: "Nusrat A.",
            },
            {
              q: "Great quality and my son actually learned his numbers playing with it!",
              n: "Rakib H.",
            },
            {
              q: "Fast delivery and the toys are exactly age-appropriate. Highly recommend.",
              n: "Tania R.",
            },
          ].map((t) => (
            <div key={t.n} className="bg-white rounded-3xl p-6 shadow-sm">
              <div className="text-amber-400 text-lg">★★★★★</div>
              <p className="mt-2 text-slate-600 italic">“{t.q}”</p>
              <p className="mt-3 font-bold text-slate-800">— {t.n}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Learning Hub teaser */}
      <section className="mx-auto max-w-7xl px-4 pb-16">
        <div className="bg-toyopurple rounded-3xl p-8 md:p-10 text-white flex flex-col md:flex-row items-center gap-6 justify-between">
          <div>
            <h2 className="brand-font text-2xl md:text-3xl font-extrabold">
              Learning Hub 📚
            </h2>
            <p className="text-white/90 mt-2">
              Free activities, age guides & parenting tips — learning through play.
            </p>
          </div>
          <Link
            href="/learning-hub"
            className="rounded-full bg-toyoyellow text-slate-900 font-bold px-7 py-3 shrink-0"
          >
            Explore Learning Hub
          </Link>
        </div>
      </section>
    </div>
  );
}

function SectionHead({
  title,
  subtitle,
  center,
}: {
  title: string;
  subtitle?: string;
  center?: boolean;
}) {
  return (
    <div className={`mb-6 ${center ? "text-center" : ""}`}>
      <h2 className="brand-font text-2xl md:text-3xl font-extrabold text-slate-800">
        {title}
      </h2>
      {subtitle && <p className="text-slate-500 mt-1">{subtitle}</p>}
    </div>
  );
}
