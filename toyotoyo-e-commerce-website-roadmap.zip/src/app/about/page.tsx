export const metadata = { title: "About ToyoToyo" };

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="brand-font text-4xl font-extrabold mb-3">About ToyoToyo 🧸</h1>
      <p className="text-lg text-slate-600 mb-6">
        ToyoToyo = <span className="font-bold text-toyo">Play</span> +{" "}
        <span className="font-bold text-toyoteal">Learn</span>. We believe every toy
        should do more than entertain — it should help a child grow.
      </p>
      <div className="grid sm:grid-cols-2 gap-4 mb-8">
        {[
          { e: "🎯", t: "Our Mission", d: "Make learning fun through carefully chosen educational toys." },
          { e: "🛡️", t: "Safety First", d: "Every product is age-appropriate and quality-checked." },
          { e: "🧠", t: "Skill Focused", d: "We label what each toy teaches — from STEM to creativity." },
          { e: "❤️", t: "Parent Trusted", d: "Recommended by families across Bangladesh." },
        ].map((c) => (
          <div key={c.t} className="bg-white rounded-2xl p-5 shadow-sm">
            <div className="text-3xl mb-2">{c.e}</div>
            <h3 className="font-bold text-lg">{c.t}</h3>
            <p className="text-slate-500 text-sm mt-1">{c.d}</p>
          </div>
        ))}
      </div>
      <p className="text-slate-600">
        Whether you shop by <b>age</b>, <b>skill</b>, or <b>interest</b>, ToyoToyo helps
        you find toys that let little hands do big learning.
      </p>
    </div>
  );
}
