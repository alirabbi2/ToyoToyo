import Link from "next/link";
import { notFound } from "next/navigation";
import { getOrderByCode } from "@/lib/orders";
import { formatTk } from "@/lib/constants";
import OrderTracker from "@/components/OrderTracker";

export const dynamic = "force-dynamic";

export default async function OrderPage({
  params,
}: {
  params: Promise<{ code: string }>;
}) {
  const { code } = await params;
  const order = await getOrderByCode(code);
  if (!order) notFound();

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <div className="text-center mb-8">
        <div className="text-6xl mb-2">🎉</div>
        <h1 className="brand-font text-3xl font-extrabold">Thank you!</h1>
        <p className="text-slate-500">
          Your order <span className="font-bold text-toyo">{order.orderCode}</span> has been placed.
        </p>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm mb-6">
        <h2 className="brand-font font-extrabold text-lg mb-5">Order Tracking</h2>
        <OrderTracker status={order.status} />
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm mb-6">
        <h2 className="brand-font font-extrabold text-lg mb-3">Items</h2>
        <div className="space-y-2">
          {order.items.map((it) => (
            <div key={it.productId} className="flex justify-between text-sm">
              <span>{it.name} × {it.quantity}</span>
              <span className="font-semibold">{formatTk(it.price * it.quantity)}</span>
            </div>
          ))}
        </div>
        <div className="border-t my-3" />
        <Row label="Subtotal" value={formatTk(order.subtotal)} />
        <Row label="Delivery" value={order.deliveryCharge === 0 ? "FREE" : formatTk(order.deliveryCharge)} />
        {order.discount > 0 && <Row label="Discount" value={"-" + formatTk(order.discount)} />}
        <Row label="Total" value={formatTk(order.total)} bold />
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm mb-6 grid sm:grid-cols-2 gap-4 text-sm">
        <div>
          <h3 className="font-bold text-slate-700 mb-1">Shipping To</h3>
          <p className="text-slate-600">
            {order.customerName}<br />
            {order.customerPhone}<br />
            {order.address}, {order.area}<br />
            {order.district}, {order.division} {order.postalCode}
          </p>
        </div>
        <div>
          <h3 className="font-bold text-slate-700 mb-1">Payment</h3>
          <p className="text-slate-600 capitalize">
            Method: {order.paymentMethod}<br />
            Status: {order.paymentStatus}<br />
            Delivery: {order.deliveryMethod}
          </p>
        </div>
      </div>

      <div className="flex gap-3 justify-center">
        <Link href="/shop" className="rounded-full bg-toyoteal text-white font-bold px-6 py-3">
          Continue Shopping
        </Link>
        <Link href="/track" className="rounded-full border-2 border-slate-200 font-bold px-6 py-3">
          Track Another Order
        </Link>
      </div>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex justify-between py-0.5 ${bold ? "text-lg font-extrabold" : "text-slate-600"}`}>
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
