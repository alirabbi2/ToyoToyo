import Link from "next/link";

export const metadata = { title: "Learning Hub · ToyoToyo" };

const ARTICLES = [
  {
    title: "5 Fun Math Games for Kids",
    age: "5–7",
    skill: "Mathematics",
    time: "15 minutes",
    difficulty: "Easy",
    emoji: "🔢",
    excerpt: "Turn everyday moments into number adventures your child will love.",
  },
  {
    title: "3 Ways to Improve Your Child's Creativity",
    age: "3–6",
    skill: "Creativity",
    time: "20 minutes",
    difficulty: "Easy",
    emoji: "🎨",
    excerpt: "Simple activities that spark imagination and self-expression.",
  },
  {
    title: "Best Toys for 3–5 Year Olds",
    age: "3–5",
    skill: "Cognitive",
    time: "10 minutes",
    difficulty: "Guide",
    emoji: "🧸",
    excerpt: "A parent's guide to age-appropriate, skill-building toys.",
  },
  {
    title: "Why Learning Through Play Works",
    age: "All",
    skill: "Development",
    time: "8 minutes",
    difficulty: "Read",
    emoji: "🧠",
    excerpt: "The science behind play-based learning explained simply.",
  },
  {
    title: "Screen-Free Activities for Kids",
    age: "4–8",
    skill: "Various",
    time: "30 minutes",
    difficulty: "Easy",
    emoji: "🌳",
    excerpt: "Keep kids engaged and learning without a screen in sight.",
  },
  {
    title: "STEM at Home: Kitchen Science",
    age: "6–10",
    skill: "STEM & Science",
    time: "25 minutes",
    difficulty: "Medium",
    emoji: "🔬",
    excerpt: "Easy experiments using things you already have at home.",
  },
];

export default function LearningHubPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <div className="bg-toyopurple text-white rounded-3xl p-8 md:p-10 mb-8">
        <h1 className="brand-font text-4xl font-extrabold mb-2">Learning Hub 📚</h1>
        <p className="text-white/90 max-w-xl">
          Free activities, age guides and parenting tips — because ToyoToyo is more
          than a toy shop. It&apos;s a resource for learning through play.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {ARTICLES.map((a) => (
          <article key={a.title} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-lg transition">
            <div className="bg-gradient-to-br from-amber-100 to-toyoteal/20 h-40 flex items-center justify-center text-7xl">
              {a.emoji}
            </div>
            <div className="p-5">
              <h2 className="brand-font font-extrabold text-lg leading-snug">{a.title}</h2>
              <p className="text-slate-500 text-sm mt-1">{a.excerpt}</p>
              <div className="flex flex-wrap gap-2 mt-3 text-xs">
                <Tag>👶 Age {a.age}</Tag>
                <Tag>🎯 {a.skill}</Tag>
                <Tag>⏱ {a.time}</Tag>
                <Tag>📊 {a.difficulty}</Tag>
              </div>
              <Link
                href={`/shop?skill=${encodeURIComponent(a.skill)}`}
                className="inline-block mt-4 text-toyo font-bold text-sm"
              >
                Shop related toys →
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="bg-amber-50 rounded-full px-2.5 py-1 font-semibold text-slate-600">
      {children}
    </span>
  );
}
