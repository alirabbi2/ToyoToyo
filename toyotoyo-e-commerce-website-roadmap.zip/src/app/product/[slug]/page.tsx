import Link from "next/link";
import { notFound } from "next/navigation";
import { getProductBySlug, getProductReviews, getRelated } from "@/lib/products";
import { formatTk, SKILL_EMOJI } from "@/lib/constants";
import ProductActions from "@/components/ProductActions";
import ReviewForm from "@/components/ReviewForm";
import ProductCard from "@/components/ProductCard";
import StarRating from "@/components/StarRating";
import ProductGallery from "@/components/ProductGallery";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [reviews, related, user] = await Promise.all([
    getProductReviews(product.id),
    getRelated(product.category, product.id),
    getCurrentUser(),
  ]);

  const eff = product.discountPrice ?? product.price;
  const hasDiscount = product.discountPrice && product.discountPrice < product.price;
  const gallery = [product.image, ...product.gallery].filter(Boolean);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <nav className="text-sm text-slate-500 mb-6">
        <Link href="/" className="hover:text-toyo">Home</Link> /{" "}
        <Link href="/shop" className="hover:text-toyo">Shop</Link> /{" "}
        <Link href={`/shop?category=${encodeURIComponent(product.category)}`} className="hover:text-toyo">
          {product.category}
        </Link>{" "}
        / <span className="text-slate-700">{product.name}</span>
      </nav>

      <div className="grid md:grid-cols-2 gap-8">
        <ProductGallery images={gallery} name={product.name} />

        <div>
          <h1 className="brand-font text-3xl font-extrabold text-slate-800">
            {product.name}
          </h1>
          <div className="flex items-center gap-2 mt-2">
            <StarRating rating={product.rating} size="text-lg" />
            <span className="text-sm text-slate-500">
              {product.rating.toFixed(1)} · {product.reviewCount} reviews
            </span>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <span className="text-3xl font-extrabold text-toyo">{formatTk(eff)}</span>
            {hasDiscount && (
              <>
                <span className="text-lg text-slate-400 line-through">
                  {formatTk(product.price)}
                </span>
                <span className="bg-toyo/10 text-toyo font-bold text-sm rounded-full px-3 py-1">
                  Save {Math.round((1 - eff / product.price) * 100)}%
                </span>
              </>
            )}
          </div>

          <p className="mt-4 text-slate-600">{product.shortDescription}</p>

          <div className="mt-4 flex flex-wrap gap-2">
            <span className="bg-amber-100 rounded-full px-3 py-1 text-sm font-semibold">
              👶 Age: {product.minAge}–{product.maxAge} Years
            </span>
            {product.skills.map((s) => (
              <span
                key={s}
                className="bg-toyoteal/10 text-toyoteal rounded-full px-3 py-1 text-sm font-semibold"
              >
                {SKILL_EMOJI[s] ?? "⭐"} {s}
              </span>
            ))}
          </div>

          <div className="mt-6">
            <ProductActions product={product} />
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
            <Info label="Material" value={product.material || "—"} />
            <Info label="SKU" value={product.sku || "—"} />
          </div>
        </div>
      </div>

      {/* Detail sections */}
      <div className="grid md:grid-cols-3 gap-6 mt-12">
        <div className="md:col-span-2 space-y-6">
          <Section title="Product Description">
            <p className="text-slate-600 whitespace-pre-line">{product.description}</p>
          </Section>

          {product.learningBenefits.length > 0 && (
            <Section title="What Will Your Child Learn?">
              <ul className="grid sm:grid-cols-2 gap-2">
                {product.learningBenefits.map((b) => (
                  <li key={b} className="flex items-center gap-2 text-slate-700">
                    <span className="text-toyoteal">✔</span> {b}
                  </li>
                ))}
              </ul>
            </Section>
          )}

          {product.howToPlay.length > 0 && (
            <Section title="How to Play">
              <ol className="space-y-2">
                {product.howToPlay.map((step, i) => (
                  <li key={i} className="flex gap-3 text-slate-700">
                    <span className="h-6 w-6 shrink-0 rounded-full bg-toyo text-white text-sm font-bold flex items-center justify-center">
                      {i + 1}
                    </span>
                    {step}
                  </li>
                ))}
              </ol>
            </Section>
          )}

          {product.whatsIncluded.length > 0 && (
            <Section title="What's Included">
              <ul className="space-y-1">
                {product.whatsIncluded.map((x) => (
                  <li key={x} className="text-slate-700">📦 {x}</li>
                ))}
              </ul>
            </Section>
          )}
        </div>

        <div className="space-y-6">
          <Section title="Safety Information">
            <p className="text-slate-600 whitespace-pre-line">
              {product.safetyInfo || "Recommended for supervised play."}
            </p>
            <div className="mt-3 text-sm text-slate-500 space-y-1">
              <p>Recommended Age: {product.minAge}+</p>
              <p>Adult Supervision: Recommended</p>
            </div>
          </Section>
        </div>
      </div>

      {/* Reviews */}
      <div className="mt-12">
        <h2 className="brand-font text-2xl font-extrabold text-slate-800 mb-4">
          Reviews ({reviews.length})
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            {reviews.length === 0 && (
              <p className="text-slate-500">No reviews yet. Be the first!</p>
            )}
            {reviews.map((r) => (
              <div key={r.id} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800">{r.authorName}</span>
                  <StarRating rating={r.rating} />
                </div>
                <p className="text-slate-600 mt-1">{r.comment}</p>
              </div>
            ))}
          </div>
          <ReviewForm productId={product.id} loggedIn={!!user} />
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-12">
          <h2 className="brand-font text-2xl font-extrabold text-slate-800 mb-4">
            You May Also Like
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm">
      <h3 className="brand-font text-xl font-extrabold text-slate-800 mb-3">{title}</h3>
      {children}
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-amber-50 rounded-xl p-3">
      <div className="text-slate-400 text-xs">{label}</div>
      <div className="font-semibold text-slate-700">{value}</div>
    </div>
  );
}
