"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function TrackPage() {
  const [code, setCode] = useState("");
  const router = useRouter();
  return (
    <div className="mx-auto max-w-lg px-4 py-16 text-center">
      <div className="text-6xl mb-3">📦</div>
      <h1 className="brand-font text-3xl font-extrabold mb-2">Track Your Order</h1>
      <p className="text-slate-500 mb-6">Enter your order code to see its status.</p>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (code.trim()) router.push(`/order/${code.trim()}`);
        }}
        className="flex gap-2"
      >
        <input
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="e.g. TOYOABC123"
          className="flex-1 rounded-full border border-slate-200 px-5 py-3 outline-none focus:border-toyoteal"
        />
        <button className="rounded-full bg-toyo text-white font-bold px-6">Track</button>
      </form>
    </div>
  );
}
