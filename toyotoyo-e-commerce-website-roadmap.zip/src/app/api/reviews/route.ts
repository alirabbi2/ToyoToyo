import { NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, products } from "@/db/schema";
import { eq, sql, and } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Please log in to review." }, { status: 401 });
  }
  const { productId, rating, comment } = (await req.json()) ?? {};
  if (!productId || !rating) {
    return NextResponse.json({ error: "Missing fields." }, { status: 400 });
  }
  await db.insert(reviews).values({
    productId: Number(productId),
    userId: user.id,
    authorName: user.name,
    rating: Math.min(5, Math.max(1, Number(rating))),
    comment: comment ?? "",
    approved: true,
  });

  // recompute product rating
  const [agg] = await db
    .select({
      avg: sql<number>`COALESCE(AVG(${reviews.rating}), 0)`,
      cnt: sql<number>`COUNT(*)`,
    })
    .from(reviews)
    .where(and(eq(reviews.productId, Number(productId)), eq(reviews.approved, true)));

  await db
    .update(products)
    .set({ rating: Number(agg.avg), reviewCount: Number(agg.cnt) })
    .where(eq(products.id, Number(productId)));

  return NextResponse.json({ ok: true });
}
