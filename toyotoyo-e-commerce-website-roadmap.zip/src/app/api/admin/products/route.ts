import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { slugify } from "@/lib/constants";

async function requireAdmin() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") return null;
  return user;
}

function parseBody(b: Record<string, unknown>) {
  const skills = Array.isArray(b.skills)
    ? b.skills
    : String(b.skills ?? "")
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
  const asList = (v: unknown) =>
    Array.isArray(v)
      ? v
      : String(v ?? "")
          .split("\n")
          .map((s) => s.trim())
          .filter(Boolean);
  return {
    name: String(b.name ?? ""),
    slug: String(b.slug ? b.slug : slugify(String(b.name ?? ""))),
    shortDescription: String(b.shortDescription ?? ""),
    description: String(b.description ?? ""),
    price: Number(b.price) || 0,
    discountPrice: b.discountPrice ? Number(b.discountPrice) : null,
    sku: String(b.sku ?? ""),
    stock: Number(b.stock) || 0,
    category: String(b.category ?? "Puzzles"),
    minAge: Number(b.minAge) || 0,
    maxAge: Number(b.maxAge) || 12,
    skills: skills as string[],
    material: String(b.material ?? ""),
    image: String(b.image ?? ""),
    gallery: asList(b.gallery) as string[],
    whatsIncluded: asList(b.whatsIncluded) as string[],
    howToPlay: asList(b.howToPlay) as string[],
    learningBenefits: asList(b.learningBenefits) as string[],
    safetyInfo: String(b.safetyInfo ?? ""),
    featured: Boolean(b.featured),
    bestSeller: Boolean(b.bestSeller),
    newArrival: Boolean(b.newArrival),
  };
}

export async function POST(req: Request) {
  if (!(await requireAdmin()))
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  const body = await req.json();
  const data = parseBody(body);
  if (!data.name) return NextResponse.json({ error: "Name required" }, { status: 400 });
  try {
    const [p] = await db.insert(products).values(data).returning();
    return NextResponse.json({ ok: true, id: p.id });
  } catch {
    return NextResponse.json({ error: "Slug must be unique." }, { status: 400 });
  }
}

export async function PUT(req: Request) {
  if (!(await requireAdmin()))
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  const body = await req.json();
  const id = Number(body.id);
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data = parseBody(body);
  await db.update(products).set(data).where(eq(products.id, id));
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  if (!(await requireAdmin()))
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.delete(products).where(eq(products.id, id));
  return NextResponse.json({ ok: true });
}
