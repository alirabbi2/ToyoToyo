import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function PUT(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin")
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  const { id, status, paymentStatus } = (await req.json()) ?? {};
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const patch: Record<string, string> = {};
  if (status) patch.status = status;
  if (paymentStatus) patch.paymentStatus = paymentStatus;
  await db.update(orders).set(patch).where(eq(orders.id, Number(id)));
  return NextResponse.json({ ok: true });
}
