import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { inArray } from "drizzle-orm";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const ids = (searchParams.get("ids") || "")
    .split(",")
    .map((s) => Number(s))
    .filter((n) => !Number.isNaN(n) && n > 0);
  if (ids.length === 0) return NextResponse.json({ products: [] });
  const rows = await db.select().from(products).where(inArray(products.id, ids));
  return NextResponse.json({ products: rows });
}
