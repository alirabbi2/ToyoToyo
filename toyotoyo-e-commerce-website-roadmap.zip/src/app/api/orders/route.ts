import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products, type OrderItem } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

function genCode() {
  return "TOYO" + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 900 + 100);
}

export async function POST(req: Request) {
  const body = await req.json();
  const {
    customerName,
    customerPhone,
    customerEmail,
    division,
    district,
    area,
    address,
    postalCode,
    deliveryMethod,
    paymentMethod,
    items,
    coupon,
  } = body ?? {};

  if (!customerName || !customerPhone || !address || !Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "Missing order information." }, { status: 400 });
  }

  // Validate items against DB prices
  const validated: OrderItem[] = [];
  let subtotal = 0;
  for (const it of items) {
    const rows = await db.select().from(products).where(eq(products.id, it.productId));
    const p = rows[0];
    if (!p) continue;
    const price = p.discountPrice ?? p.price;
    const qty = Math.max(1, Number(it.quantity) || 1);
    validated.push({
      productId: p.id,
      name: p.name,
      slug: p.slug,
      image: p.image,
      price,
      quantity: qty,
    });
    subtotal += price * qty;
  }
  if (validated.length === 0) {
    return NextResponse.json({ error: "No valid items." }, { status: 400 });
  }

  const deliveryCharge = deliveryMethod === "express" ? 150 : subtotal >= 2000 ? 0 : 60;
  let discount = 0;
  if (coupon && String(coupon).toUpperCase() === "TOYO10" && subtotal >= 1000) {
    discount = Math.min(Math.round(subtotal * 0.1), 500);
  }
  const total = subtotal + deliveryCharge - discount;

  const user = await getCurrentUser();

  const [order] = await db
    .insert(orders)
    .values({
      orderCode: genCode(),
      userId: user?.id ?? null,
      customerName,
      customerPhone,
      customerEmail: customerEmail ?? "",
      division: division ?? "",
      district: district ?? "",
      area: area ?? "",
      address,
      postalCode: postalCode ?? "",
      deliveryMethod: deliveryMethod ?? "standard",
      paymentMethod: paymentMethod ?? "cod",
      paymentStatus: "unpaid",
      status: "pending",
      items: validated,
      subtotal,
      deliveryCharge,
      discount,
      total,
    })
    .returning();

  // decrement stock
  for (const it of validated) {
    await db
      .update(products)
      .set({ stock: sql`GREATEST(${products.stock} - ${it.quantity}, 0)` })
      .where(eq(products.id, it.productId));
  }

  return NextResponse.json({ ok: true, orderCode: order.orderCode });
}
