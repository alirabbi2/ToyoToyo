import Link from "next/link";
import { Suspense } from "react";
import { getProducts, type ProductFilters } from "@/lib/products";
import ProductCard from "@/components/ProductCard";
import ShopFilters from "@/components/ShopFilters";
import SortSelect from "@/components/SortSelect";
import { AGE_GROUPS, SKILLS } from "@/lib/constants";

export const dynamic = "force-dynamic";

type SP = Promise<Record<string, string | undefined>>;

export default async function ShopPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;

  if (sp.ageView) return <AgeLanding />;
  if (sp.skillView) return <SkillLanding />;

  const filters: ProductFilters = {
    q: sp.q,
    minAge: sp.minAge !== undefined ? Number(sp.minAge) : undefined,
    maxAge: sp.maxAge !== undefined ? Number(sp.maxAge) : undefined,
    skill: sp.skill,
    category: sp.category,
    minPrice: sp.minPrice !== undefined ? Number(sp.minPrice) : undefined,
    maxPrice: sp.maxPrice !== undefined ? Number(sp.maxPrice) : undefined,
    featured: sp.featured === "1",
    bestSeller: sp.bestSeller === "1",
    newArrival: sp.newArrival === "1",
    sort: sp.sort,
  };

  const products = await getProducts(filters);

  let heading = "All Products";
  if (filters.featured) heading = "Featured Products";
  else if (filters.bestSeller) heading = "Best Sellers";
  else if (filters.newArrival) heading = "New Arrivals";
  else if (filters.skill) heading = filters.skill;
  else if (filters.category) heading = filters.category;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="brand-font text-3xl font-extrabold text-slate-800">{heading}</h1>
          <p className="text-slate-500">{products.length} products</p>
        </div>
        <Suspense>
          <SortSelect />
        </Suspense>
      </div>

      <div className="grid md:grid-cols-[260px_1fr] gap-6">
        <Suspense>
          <ShopFilters />
        </Suspense>
        <div>
          {products.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center text-slate-500">
              <div className="text-5xl mb-3">🔍</div>
              No products match your filters.
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AgeLanding() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="brand-font text-3xl font-extrabold text-slate-800 mb-2">Shop by Age</h1>
      <p className="text-slate-500 mb-8">Choose the right stage for your child.</p>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-5">
        {AGE_GROUPS.map((a) => (
          <Link
            key={a.label}
            href={`/shop?minAge=${a.min}&maxAge=${a.max}`}
            className="bg-white rounded-3xl p-8 text-center shadow-sm hover:shadow-lg hover:-translate-y-1 transition"
          >
            <div className="text-6xl mb-3">{a.emoji}</div>
            <div className="font-bold text-lg text-slate-800">{a.label}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}

function SkillLanding() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="brand-font text-3xl font-extrabold text-slate-800 mb-2">Shop by Skill</h1>
      <p className="text-slate-500 mb-8">Discover what each toy teaches.</p>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
        {SKILLS.map((s) => (
          <Link
            key={s.label}
            href={`/shop?skill=${encodeURIComponent(s.label)}`}
            className="bg-white rounded-3xl p-6 text-center shadow-sm hover:shadow-lg transition"
          >
            <div className="text-5xl mb-3">{s.emoji}</div>
            <div className="font-bold text-slate-800">{s.label}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
