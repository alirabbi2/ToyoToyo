"use client";

import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { formatTk } from "@/lib/constants";

export default function CartPage() {
  const { items, setQuantity, removeFromCart, subtotal, ready } = useCart();

  if (!ready) return <div className="p-12 text-center text-slate-400">Loading…</div>;

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20 text-center">
        <div className="text-7xl mb-4">🛒</div>
        <h1 className="brand-font text-2xl font-extrabold mb-2">Your cart is empty</h1>
        <p className="text-slate-500 mb-6">Let&apos;s find something fun to learn with!</p>
        <Link href="/shop" className="rounded-full bg-toyoteal text-white font-bold px-8 py-3">
          Start Shopping
        </Link>
      </div>
    );
  }

  const delivery = subtotal >= 2000 ? 0 : 60;

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="brand-font text-3xl font-extrabold mb-6">Your Cart</h1>
      <div className="grid md:grid-cols-[1fr_320px] gap-6">
        <div className="space-y-3">
          {items.map((it) => (
            <div key={it.productId} className="bg-white rounded-2xl p-4 shadow-sm flex gap-4 items-center">
              <Link href={`/product/${it.slug}`} className="h-20 w-20 rounded-xl overflow-hidden bg-amber-50 flex items-center justify-center shrink-0">
                {it.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={it.image} alt={it.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-3xl">🧸</span>
                )}
              </Link>
              <div className="flex-1 min-w-0">
                <Link href={`/product/${it.slug}`} className="font-bold text-slate-800 line-clamp-2 hover:text-toyo">
                  {it.name}
                </Link>
                <div className="text-toyo font-bold">{formatTk(it.price)}</div>
              </div>
              <div className="flex items-center rounded-full bg-amber-50 border border-amber-100">
                <button onClick={() => setQuantity(it.productId, it.quantity - 1)} className="h-8 w-8 font-bold">−</button>
                <span className="w-8 text-center font-bold">{it.quantity}</span>
                <button onClick={() => setQuantity(it.productId, it.quantity + 1)} className="h-8 w-8 font-bold">+</button>
              </div>
              <div className="text-right w-20 font-bold hidden sm:block">
                {formatTk(it.price * it.quantity)}
              </div>
              <button onClick={() => removeFromCart(it.productId)} className="text-slate-400 hover:text-toyo text-xl">
                🗑
              </button>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm h-fit sticky top-40">
          <h2 className="brand-font font-extrabold text-xl mb-4">Order Summary</h2>
          <Row label="Subtotal" value={formatTk(subtotal)} />
          <Row label="Delivery" value={delivery === 0 ? "FREE" : formatTk(delivery)} />
          <div className="border-t my-3" />
          <Row label="Total" value={formatTk(subtotal + delivery)} bold />
          <Link
            href="/checkout"
            className="mt-5 block text-center rounded-full bg-toyo text-white font-bold py-3"
          >
            Proceed to Checkout
          </Link>
          <Link href="/shop" className="mt-2 block text-center text-sm text-slate-500 font-semibold">
            Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex justify-between py-1 ${bold ? "text-lg font-extrabold" : "text-slate-600"}`}>
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
