import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getOrdersByUser } from "@/lib/orders";
import { formatTk } from "@/lib/constants";
import LogoutButton from "@/components/LogoutButton";

export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const orders = await getOrdersByUser(user.id);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="brand-font text-3xl font-extrabold">My Account</h1>
          <p className="text-slate-500">Welcome, {user.name} 👋</p>
        </div>
        <LogoutButton className="rounded-full border-2 border-slate-200 px-5 py-2 font-bold text-slate-600" />
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <Stat label="Total Orders" value={String(orders.length)} emoji="📦" />
        <Stat
          label="Total Spent"
          value={formatTk(orders.reduce((s, o) => s + o.total, 0))}
          emoji="💰"
        />
        <Link href="/wishlist" className="bg-white rounded-3xl p-5 shadow-sm flex items-center gap-3">
          <span className="text-3xl">💝</span>
          <span className="font-bold">My Wishlist →</span>
        </Link>
      </div>

      <h2 className="brand-font text-2xl font-extrabold mb-4">My Orders</h2>
      {orders.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 text-center text-slate-500">
          No orders yet.{" "}
          <Link href="/shop" className="text-toyo font-bold">Start shopping →</Link>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <Link
              key={o.id}
              href={`/order/${o.orderCode}`}
              className="block bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition"
            >
              <div className="flex justify-between items-center flex-wrap gap-2">
                <div>
                  <div className="font-bold text-slate-800">{o.orderCode}</div>
                  <div className="text-sm text-slate-500">
                    {o.items.length} item(s) · {new Date(o.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold capitalize">
                    {o.status.replace(/_/g, " ")}
                  </span>
                  <span className="font-extrabold text-toyo">{formatTk(o.total)}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, emoji }: { label: string; value: string; emoji: string }) {
  return (
    <div className="bg-white rounded-3xl p-5 shadow-sm">
      <div className="text-3xl mb-1">{emoji}</div>
      <div className="text-2xl font-extrabold">{value}</div>
      <div className="text-sm text-slate-500">{label}</div>
    </div>
  );
}
