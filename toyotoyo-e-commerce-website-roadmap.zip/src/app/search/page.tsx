import { Suspense } from "react";
import { getProducts } from "@/lib/products";
import ProductCard from "@/components/ProductCard";
import SearchBox from "@/components/SearchBox";

export const dynamic = "force-dynamic";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const products = q ? await getProducts({ q }) : [];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="brand-font text-3xl font-extrabold mb-4">Search</h1>
      <Suspense>
        <SearchBox initial={q ?? ""} />
      </Suspense>
      {q && (
        <p className="text-slate-500 mt-4 mb-6">
          {products.length} result{products.length !== 1 && "s"} for “{q}”
        </p>
      )}
      {q && products.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center text-slate-500">
          <div className="text-5xl mb-3">🔍</div>
          No toys found. Try &quot;Montessori&quot; or &quot;puzzle&quot;.
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
